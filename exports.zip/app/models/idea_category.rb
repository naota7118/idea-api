class Idea_category < ApplicationRecord
  belongs_to :idea
  belongs_to :category
end