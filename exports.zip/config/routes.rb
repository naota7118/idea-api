Rails.application.routes.draw do
  resources :ideas
end